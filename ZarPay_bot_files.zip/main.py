import os, logging
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import requests
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
NAME, PHONE = range(2)
users = {}
MENU = ReplyKeyboardMarkup([["📈 Нархи тилло", "🧮 Ҳисобкунак"], ["🛒 Хариду фурӯш", "👤 Ҳисоби ман"], ["ℹ️ Қоидаҳои бот"]], resize_keyboard=True)

def prices():
    g = requests.get("https://api.gold-api.com/price/XAU", timeout=15)
    g.raise_for_status()
    gold = float(g.json()["price"])
    r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=15)
    r.raise_for_status()
    fx = r.json()
    if fx.get("result") != "success" or "TJS" not in fx.get("rates", {}):
        raise ValueError("USD/TJS rate unavailable")
    rate = float(fx["rates"]["TJS"])
    return gold, rate, datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

def somoni(n): return f"{n:,.2f} сомонӣ"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid in users:
        await update.message.reply_text(f"Салом боз, {users[uid]['name']}! 💎", reply_markup=MENU)
        return ConversationHandler.END
    await update.message.reply_text("Салом ба ZarPay! 💎\nБарои оғоз ному насаби худро нависед:")
    return NAME

async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.message.text.strip()
    if len(name) < 2 or len(name) > 80:
        await update.message.reply_text("Лутфан ному насаби дурустро нависед.")
        return NAME
    context.user_data["name"] = name
    kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Фиристодани рақами телефон", request_contact=True)]], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("Ташаккур! Рақами телефонро бо тугма фиристед ё дастӣ нависед.", reply_markup=kb)
    return PHONE

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    c = update.message.contact
    if c and c.user_id and c.user_id != update.effective_user.id:
        await update.message.reply_text("Рақами телефони худатонро фиристед.")
        return PHONE
    phone = c.phone_number if c else update.message.text.strip()
    if len(phone) < 5 or len(phone) > 30:
        await update.message.reply_text("Рақам дуруст нест. Бори дигар фиристед.")
        return PHONE
    users[update.effective_user.id] = {"name": context.user_data["name"], "phone": phone}
    await update.message.reply_text("✅ Сабти ном анҷом ёфт! Аз меню интихоб кунед.", reply_markup=MENU)
    return ConversationHandler.END

async def price_message():
    try:
        usd_oz, usd_tjs, updated = prices()
        gram = usd_oz / 31.1034768 * usd_tjs
        return ("📈 Нархи тахминии бозории тиллои холис (24K)\n\n"
                f"• 1 грамм: {somoni(gram)}\n• 10 грамм: {somoni(gram*10)}\n"
                f"• 1 унсияи тройӣ: {somoni(usd_oz*usd_tjs)}\n"
                f"Нархи тилло: ${usd_oz:,.2f}/унсия\nҚурби USD/TJS: {usd_tjs:.4f}\nНавсозӣ: {updated}\n\n"
                "Эзоҳ: ин нархи спот аст, на нархи кафолатноки мағоза.")
    except Exception:
        logging.exception("Price fetch failed")
        return "⚠️ Ҳоло нархи онлайн дастрас нест. Каме баъдтар кӯшиш кунед; нархи тахминӣ сохта нишон дода намешавад."

async def show_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(await price_message(), reply_markup=MENU)

async def calc_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("24K — 999", callback_data="k24"), InlineKeyboardButton("22K — 916", callback_data="k22")],
                               [InlineKeyboardButton("21K — 875", callback_data="k21"), InlineKeyboardButton("18K — 750", callback_data="k18")]])
    await update.message.reply_text("Аёри тиллоро интихоб кунед:", reply_markup=kb)

async def choose_karat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query; await q.answer()
    k = int(q.data[1:]); context.user_data["karat"] = k
    await q.edit_message_text(f"Аёри {k}K интихоб шуд. Вазнро бо грамм фиристед (масалан 5.5).")

async def calc_weight(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if "karat" not in context.user_data:
        await update.message.reply_text("Аз меню аввал 🧮 Ҳисобкунакро интихоб кунед.", reply_markup=MENU); return
    try:
        grams = Decimal(update.message.text.replace(",", ".").strip())
        if grams <= 0 or grams > Decimal("10000"): raise InvalidOperation
    except (InvalidOperation, ValueError):
        await update.message.reply_text("Вазнро бо рақам нависед, масалан 5.5"); return
    try:
        usd_oz, usd_tjs, updated = prices()
        pure = usd_oz / 31.1034768 * usd_tjs
        k = context.user_data["karat"]
        value = float(grams) * pure * (k / 24)
        await update.message.reply_text(f"🧮 Ҳисоби тахминии тиллои {k}K\n\nВазн: {grams} г\nНархи тахминии 1 г: {somoni(pure*k/24)}\nАрзиши металл: {somoni(value)}\nНавсозӣ: {updated}\n\nМузди кор, санҷиши аёр ва фоидаи харидор/фурӯшанда дохил нест.", reply_markup=MENU)
    except Exception:
        await update.message.reply_text(await price_message(), reply_markup=MENU)

async def buy_sell(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🛒 ZarPay нархи тахминии бозориро ҳисоб мекунад. Ҳоло бот худ аз худ тилло намехарад, намефурӯшад ва пардохт намегузаронад. Нархи воқеии мағоза метавонад фарқ кунад.", reply_markup=MENU)

async def account(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = users.get(update.effective_user.id)
    await update.message.reply_text(f"👤 Ҳисоби ман\nНом: {u['name']}\nТелефон: {u['phone']}" if u else "Маълумоти ҳисоб нест. /start-ро пахш кунед.", reply_markup=MENU)

async def rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("ℹ️ Қоидаҳо\n1. Нархҳо тахминӣ буда, аз нархи ҷаҳонӣ ва қурби USD/TJS гирифта мешаванд.\n2. Нархи мағоза метавонад фарқ кунад.\n3. Ҳисобкунак танҳо арзиши тахминии металлро ҳисоб мекунад.\n4. Бот ҳоло муомила ё пардохт анҷом намедиҳад.", reply_markup=MENU)

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Бекор шуд. Барои оғоз /start нависед.")
    return ConversationHandler.END

def main():
    if not BOT_TOKEN: raise RuntimeError("Set BOT_TOKEN as an environment variable")
    app = Application.builder().token(BOT_TOKEN).build()
    signup = ConversationHandler(entry_points=[CommandHandler("start", start)],
        states={NAME:[MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
                PHONE:[MessageHandler(filters.CONTACT, get_phone), MessageHandler(filters.TEXT & ~filters.COMMAND, get_phone)]},
        fallbacks=[CommandHandler("cancel", cancel)], allow_reentry=True)
    app.add_handler(signup)
    app.add_handler(CallbackQueryHandler(choose_karat, pattern=r"^k(24|22|21|18)$"))
    app.add_handler(MessageHandler(filters.Regex(r"^📈 Нархи тилло$"), show_price))
    app.add_handler(MessageHandler(filters.Regex(r"^🧮 Ҳисобкунак$"), calc_start))
    app.add_handler(MessageHandler(filters.Regex(r"^🛒 Хариду фурӯш$"), buy_sell))
    app.add_handler(MessageHandler(filters.Regex(r"^👤 Ҳисоби ман$"), account))
    app.add_handler(MessageHandler(filters.Regex(r"^ℹ️ Қоидаҳои бот$"), rules))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, calc_weight))
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__": main()
