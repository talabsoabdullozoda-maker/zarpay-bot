ZarPay Telegram bot files

1. Create a GitHub repository named zarpay-bot.
2. Upload main.py and requirements.txt.
3. On Render, use a Background Worker for a polling Telegram bot.
4. Build command: pip install -r requirements.txt
5. Start command: python main.py
6. Add environment variable BOT_TOKEN and set its value to your BotFather token. Never put the token in GitHub or share it in chat.

The bot fetches gold spot price from https://api.gold-api.com/price/XAU and USD/TJS from https://open.er-api.com/v6/latest/USD.
The calculator gives an indicative metal-only value; it is not a guaranteed shop price. User registration is currently kept in memory and resets on restart.
